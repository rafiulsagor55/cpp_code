#include <iostream>
#include <unordered_map>
#include <sstream>
#include <vector>

std::vector<std::pair<int, int>> remove_duplicates_and_print_occurrences(const std::vector<int>& input_sequence) {
    std::unordered_map<int, int> occurrences;
    for (int num : input_sequence) {
        occurrences[num]++;
    }

    std::vector<std::pair<int, int>> result;
    for (int num : input_sequence) {
        if (occurrences[num] > 0) {
            result.push_back({num, occurrences[num]});
            occurrences[num] = 0; // Mark the occurrence as visited
        }
    }

    return result;
}

int main() {
    std::string input;
    std::getline(std::cin, input);
    std::istringstream iss(input);

    int num;
    std::vector<int> input_sequence;
    while (iss >> num) {
        input_sequence.push_back(num);
    }

    std::vector<std::pair<int, int>> output = remove_duplicates_and_print_occurrences(input_sequence);

    for (const auto& pair : output) {
        std::cout << pair.first << " " << pair.second << "\n";
    }

    return 0;
}