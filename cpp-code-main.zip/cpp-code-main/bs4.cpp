#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N= 1e5+10;
int iscount(vector<int>&arr,int n,int s){
	for (int i = 0; i < arr.size(); ++i)
	{
		if (n>=arr[i])
		{
			continue;
		}
		else if (n<arr[i] && arr[i]<s)
		{
			s-=arr[i];
		}
		else {
			return -1;
		}
	}
	return s;

}


int main(){
 int t;
 cin>>t;
 while(t--){
 	ll n,s;
 	cin>>n>>s;
 	vector<int>arr;
 	ll mx=LONG_MIN;
 	for (int i = 0; i < n; ++i)
 	{
 		ll x;
 		cin>>x;
 		arr.push_back(x);
 		mx=max(mx,x);
 		
 	}
 	
 	int hi=mx;
 	int lo=0;
 	int mid;
 	int flag;
 	while(hi>=lo){
 		mid=lo+((hi-lo)/2);
 		
         
         if (iscount(arr,mid,s)>0)
         {
         	hi=mid-1;
         	flag=mid;
         }
         else{
         	lo=mid+1;
         }

 	}
 	cout<<flag<<endl;

 } 
  return 0;
}