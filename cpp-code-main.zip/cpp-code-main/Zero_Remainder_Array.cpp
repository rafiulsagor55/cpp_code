#include<bits/stdc++.h>
using namespace std;
vector<vector<int>>dp(100,vector<int>(100,-1));
vector<int>vtr(10000,-1);
int recurPermute(vector<int>&arr,int n,int idx,int sum,vector<int>&ds,vector<vector<int>>&v) 
{
	          // if (vtr[n]==vtr[n-1] && n!=0)
	          // {
	          // 	idx=0,sum=0;
	          // }
              if (n<=arr.size())
              {
              	if (idx==sum && idx!=0)
              	{
              		v.push_back(ds);
              		return 1;
              	}
              }
              if (n==arr.size())
              	{
              		return 0;
              	}
              	
                      
     int take=0;int nottake=0;
     ds.push_back(arr[n]);
     vtr[n]=idx;
     take=recurPermute(arr,n+1,idx+1,sum+arr[n],ds,v);
     ds.pop_back();
     nottake=recurPermute(arr,n+1,idx,sum,ds,v);              
      return (take+nottake);    
}     
int main()
{
	vector<int> arr={1,1,0,1,1};
	vector<vector<int>>v;
	vector<int>ds;
		
	map<vector<int>,int>mp;
	int x=recurPermute(arr,0,0,0,ds,v);
	for(auto it: v){
		for(auto itt:it){
			cout<<itt<<" ";
		}
		cout<<endl;
	}
	cout<<x<<endl<<endl;
	

	return 0;
}