#include<bits/stdc++.h>
using namespace std;
#define ll long long int
int main()
{
	ll n;
	cin>>n;
	vector<ll>dp(n+1,999999999);
	dp[0]=0;
	for (int i = 1; i <= n; ++i)
	{
		string s=to_string(i);
		for (int j = 0; j < s.size(); ++j)
		{
			int x=s[j]-48;
			dp[i]=min(dp[i],(1+dp[i-x]));
		}
	}
	cout<<dp[n];
  
  return 0;
}
