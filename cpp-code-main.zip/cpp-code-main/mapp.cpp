#include<bits/stdc++.h>
using namespace std;
int main()
{ 
map<pair<int,int>,string>mp;
int n;
cin>>n;
for (int i = 0; i < n; ++i)
{
	int x1,x2;
	string s;
	cin>>x1>>x2>>s;
	mp[{x1,x2}]=s;
}
int t;
cin>>t;
for (int i = 0; i < t; ++i)
{
	int p1,p2;
	cin>>p1>>p2;
	cout<<mp[{p1,p2}]<<endl;
}
return 0;
}