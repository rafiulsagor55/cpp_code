#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N= 1e5+10;
int main(){
   int t;
   cin>>t;
   while(t--){
   	vector<int>arr;
     int n;
     cin>>n;
     
     for (int i = 0; i < n; ++i)
     {
       ll x;
       cin>>x;
       arr.push_back(x);
      }
      set<ll>s;
      ll i=0;
      ll sum=0;
      while(i<n){
         
        if (arr[i]<0)
        {
         while(arr[i]<0 && i<n){
         s.insert(arr[i]);
         i++;
         }
        }
        else
          {
         while(arr[i]>0 && i<n){
         s.insert(arr[i]);
         i++;
         }
        }
          auto it =s.rbegin();
          //cout<<*it<<endl;
          sum+=*it;
          s.clear();


      }
      cout<<sum<<endl;
  }

  
  return 0;
}
