#include<bits/stdc++.h>
using namespace std;
#define ll long long int
vector<ll>h_cnt(200005,0);
vector<ll>cat(200005,0);
void dfs(int par,vector<int>graph[],vector<ll>&vis,int &m)
{
	vis[par]=1;
	for (int child:graph[par])
	{
		
		if(vis[child]==0)
		{	if (cat[child]==1)
			{
				cat[child]+=cat[par];
			}
			else
			{
				cat[child]=0;
			}
			if (cat[child]<=m)
					{
						dfs(child,graph,vis,m);

					}		
            
		}
		
	}

}
void dfs_1(int par,vector<int>graph[],vector<ll>&vi)
{
	vi[par]=1;
	for (int child:graph[par])
	{		
		if(vi[child]==0)
		{						
			dfs_1(child,graph,vi);
			h_cnt[par]=max(h_cnt[par],h_cnt[child]+1);							            
		}		
	}
}
int main()
{
	int n,m;
	cin>>n>>m;
	vector<int>graph[n+1];
	vector<ll>vis(n+1,0);
	vector<ll>vi(n+1,0);
	for (int i = 1; i <= n; ++i)
	{
		cin>>cat[i];
	}
	for (int i = 0; i < n-1; ++i)
	{
		int x,y;
		cin>>x>>y;
		graph[x].push_back(y);
		graph[y].push_back(x);
	}
	dfs(1,graph,vis,m);
	dfs_1(1,graph,vi);
	ll sum=0;
	for (int i = 1; i <= n; ++i)
	{
		if (h_cnt[i]==0 && vis[i]==1)
		{
			sum++;
		}
	}
	cout<<sum<<endl;
	
  return 0;
}