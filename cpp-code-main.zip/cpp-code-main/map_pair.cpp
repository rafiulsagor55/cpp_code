#include<bits/stdc++.h>
using namespace std;
#define ll long long int
int main()
{
 int t;
 cin>>t;
 while(t--)
 {
 	int n,l,r;
 	cin>>n>>l>>r;
 	map<pair<ll,ll>,ll>mp;
 	ll x;
 	cin>>x;
 	mp[{(x%l),(x%r)}]++;
 	ll ans=0;
 	for (int i = 0; i < n-1; ++i)
 	{
 		ll y;
 		cin>>y;
 		ll l1=y%l;
 		ll r1=y%r;
 		if(l1!=0)l1=l-l1;
 		// if(r1!=0)r1=r-r1;
 		ans+=mp[{l1,(y%r)}];
 		mp[{(y%l),(y%r)}]++;

 	}

 	cout<<ans<<endl;

 } 
  return 0;
}