#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10;
bool vi[N];
vector<int>g[N];
vector<int>colour(N,-1);
//vector<vector<int>>cc;
//vector<int>c_cc;

bool graph(int vertex,int par){ 
    vi[vertex]=true;
    bool isloop=true;
    if (colour[vertex]==-1)
    {
    	colour[vertex]=1;
    }
	for(int child:g[vertex]){
		if (colour[child]==colour[vertex]) return false;
		if (colour[child]==-1)
		{
        colour[child]=1-colour[vertex];
			
		}
		if(vi[child])continue;-
		isloop|=graph(child,vertex);
	}
return isloop;
}
int main(){
int v,e;
cin>>v>>e;
for (int i = 0; i < e; ++i)
{
	int x1,x2;
	cin>>x1>>x2;
	g[x1].push_back(x2);
	g[x2].push_back(x1);
}

    cout<<graph(1,0);

return 0;
}