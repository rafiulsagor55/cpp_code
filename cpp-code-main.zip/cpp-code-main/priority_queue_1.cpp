#include<bits/stdc++.h>
using namespace std;
long long p,k,r,t;
priority_queue<int> q;
int main()
{
    q.push(0);
    q.push(0);
    q.push(1);
    q.push(1);
    q.push(4);
    q.push(4);
    while(!q.empty())
    {
        cout<<q.top()<<" ";
        q.pop();
    }

   return 0;     
}
