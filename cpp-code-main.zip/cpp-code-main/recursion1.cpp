#include<bits/stdc++.h>
using namespace std;

void recurPermute(vector<int> &arr,vector<int> &ds, int idx,int &mx,int n,int sum,vector<vector<int>>&v,map<vector<int>,int>&mp) {
         
          if (idx==n)
          {
          	if (sum==0 && mp[ds]==0)
          	{
          		v.push_back(ds);
          		int x=ds.size();
          		mx=min(mx,x);
          		mp[ds]=1;
          	}
          	return;
          }
         if (arr[idx]<=sum)
         {
         	
         ds.push_back(arr[idx]);
         recurPermute(arr,ds,idx,mx,n,sum-arr[idx],v,mp);  
         ds.pop_back();
         
         }
         recurPermute(arr,ds,idx+1,mx,n,sum,v,mp);

}
    int main(){
	vector<int> arr={12,1,3};
	vector<vector<int>>v;
	vector<int>ds;
	vector<int>freq(arr.size(),-1);
	int mx=99999;
	map<vector<int>,int>mp;
	recurPermute(arr,ds,0,mx,arr.size(),4,v,mp);
	//cout<<x<<endl;
	for(auto it: v){
		for(auto itt:it){
			cout<<itt<<" ";
		}
		cout<<endl;
	}
	cout<<mx;

	return 0;
}