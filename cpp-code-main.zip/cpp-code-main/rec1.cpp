#include<bits/stdc++.h>
using namespace std;
void re(int *arr,int inx,int n,int sum,vector<int>&temp,vector<vector<int>>&v){
    
	if (inx==n)
	{
		if (sum==0)
		{
			v.push_back(temp);
			
		}
		return;	
	}
	if (arr[inx]!=arr[inx+1] && sum>=arr[inx])
	{
		temp.push_back(arr[inx]);
		re(arr,inx+1,n,sum-arr[inx],temp,v);
		temp.pop_back();
	}

re(arr,inx+1,n,sum,temp,v);
}
    int main(){
	int arr[]={1,1,2,5,6,7,10};
	vector<vector<int>>v;
	vector<int>temp;
	re(arr,0,7,8,temp,v);
	for(auto it: v){
		for(auto itt:it){
			cout<<itt<<" ";
		}
		cout<<endl;
		
	}
	return 0;
}
