#include<bits/stdc++.h>
using namespace std;
#define ll long long int
int const N=5e5+1;
vector<int>graph[N];
void dfs(int par,int &ver,vector<int>&vis)
{
	vis[par]=1;
	ver++;
	for (int child:graph[par])
	{
		
		if(vis[child]==0)
		{
            dfs(child,ver,vis);
		}
		
	}


}
void bfs(int par,int &ver,vector<int>&vi,map<int,int>&mp)
{
	vi[par]=1;
	mp[par]=ver;
	for (int child:graph[par])
	{
		
		if(vi[child]==0)
		{
            bfs(child,ver,vi,mp);
		}
		
	}


}
int main()
{
	int n,m;
	cin>>n>>m;
	for (int i = 1; i <= n; ++i)
	{
		int k;
		cin>>k;
		int y;
		if(k!=0)cin>>y;
		for (int i = 0; i < k-1; ++i)
		{
			    int x;
			    cin>>x;
				graph[x].push_back(y);
		        graph[y].push_back(x);
		        y=x;
			
		}
	}
    vector<int>vis(n+1,0);
    vector<int>vi(n+1,0);
	int cnt=0;
	map<int,int>mp;
	for (int i = 1; i <= n; ++i)
	{
		int ver=0;
		if(vis[i])continue;
		dfs(i,ver,vis);
		if (vi[i]==0)
		{
			bfs(i,ver,vi,mp);
		}
		

	}
	for (int i = 1; i <= n; ++i)
	{
		cout<<mp[i]<<" ";
	}
	
  return 0;
}