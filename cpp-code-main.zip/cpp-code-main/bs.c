#include<bits/stdc++.h>
using namespace std;

int main() {
    int N, M;
    cin >> N >> M;

    vector<unordered_set<int>> friends(N + 1); // Initialize a vector of sets for friendship relationships

    for (int i = 0; i < M; i++) {
        int A, B;
        cin >> A >> B;
        friends[A].insert(B); // Add B to A's set of friends
        friends[B].insert(A); // Add A to B's set of friends
    }

    int count = 0;
    for (int i = 1; i <= N; i++) {
        for (auto friend : friends[i]) {
            for (auto friendOfFriend  friends[friend]) {
                if (friendOfFriend != i && friends[i].count(friendOfFriend) == 0) {
                    count++; // Increment count when a new friendship is formed
                }
            }
        }
    }

    cout << count / 2 << endl; // Each friendship is counted twice, so divide by 2 to get the total new friendships
    return 0;
}