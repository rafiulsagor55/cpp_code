#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N= 1e5+10;
//vector<int>arr(N);
 int bs(int n){

    ll lo=1;
    ll hi=sqrt(n);
    ll mid;
    while(lo<=hi){
        mid=lo+((hi-lo)/2);
        ll x=((mid*((3*mid)+1))/2);
        if (x==n)
        {
            return mid;
        }
        else if (x>n)
        {
        	hi=mid-1;
        }
        else if (n>x)
        {
        	lo=mid+1;
        }
    }

  return hi;

 }
int main(){
     
      int t;
      cin>>t;
      while(t--){
     ll n;
     cin>>n;
     int count=0;
     while(n>1){
       int m=bs(n);
     ll x=((m*((3*m)+1))/2);
     n-=x;
     count++;
 
     }
     
     cout<<count<<endl;   
     
      } 
       
  
  return 0;
}
