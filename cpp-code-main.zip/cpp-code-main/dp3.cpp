#include <bits/stdc++.h> 
using namespace std;
const int N=1e6+10;
vector<int>sum(N,0);
int main()
{
	
	string s;
	cin>>s;
	
	for (int i = 1; i < s.size(); ++i)
	{
		if (s[i]=='.'&& s[i-1]=='.')
		{
			sum[i+1]=sum[i]+1;
		}
		else if (s[i]=='#'&& s[i-1]=='#')
		{
			sum[i+1]=sum[i]+1;
		}
		else sum[i+1]=sum[i];
		
	}
	
    int n;
	cin>>n;
	for (int i = 0; i < n; ++i)
	{
		int x,y;
		cin>>x>>y;
		cout<<(sum[y]-sum[x])<<endl;

	}
//cout<<sum[4];


	return 0;
}