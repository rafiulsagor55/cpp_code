#include<bits/stdc++.h>
using namespace std;
#define ll long long int
vector<ll>c_cnt(200005,0);
vector<ll>d(200005,0);
void dfs(int par,vector<int>graph[],vector<ll>&vis)
{
	vis[par]=1;
	for (int child:graph[par])
	{
		
		if(vis[child]==0)
		{
			
			d[child]=d[par]+1;
            dfs(child,graph,vis);
            c_cnt[par]+=(c_cnt[child]+1);
		}
		
	}

}
int main()
{
	int n,m;
	cin>>n>>m;
	vector<int>graph[n+1];
	vector<ll>vis(n+1,0);
	for (int i = 0; i < n-1; ++i)
	{
		int x,y;
		cin>>x>>y;
		graph[x].push_back(y);
		graph[y].push_back(x);
	}
	dfs(1,graph,vis);
	ll sum=0;
	priority_queue<ll> q;
	for (int i = 1; i <= n; ++i)
	{
		ll x=(d[i]-c_cnt[i]);
		q.push(x);
	}
	for (int i = 0; i < m; ++i)
	{
		sum+=(q.top());
		q.pop();
	}
	cout<<sum<<endl;
	
  return 0;
}