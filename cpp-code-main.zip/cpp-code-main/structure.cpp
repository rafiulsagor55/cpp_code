#include<stdio.h>
#include<string.h>
typedef struct sagor
	{
		char ch[20];
		int a;
		int b;
		int c;
		int d;
		

	}sagor;
void change(sagor *p)
{
	strcpy(p->ch,"kkjhj kjbhj");
    p->a+=p->c;
    //p->b+=p->d;
    (*p).b+=(*p).d;

    printf("%s  %d %d\n",p->ch,p->a,p->b);

}
int main()
{
	

	sagor s;
	scanf("%[^\n]",s.ch);
	getchar();
	scanf("%d",&s.a);
	scanf("%d",&s.b);
	scanf("%d",&s.c);
	scanf("%d",&s.d);
	printf("%s  %d %d %d %d\n",s.ch,s.a,s.b,s.c,s.d);
	change(&s);
	
	return 0;
}