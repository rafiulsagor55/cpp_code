#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10;
//bool vi[N];
vector<int>g[N];
//vector<vector<int>>cc;
vector<int>depth(N),height(N);

void graph(int vertex,int par){ 
    //vi[vertex]=true;
	for(int child:g[vertex]){
		if (child==par) continue;
		depth[child]=depth[vertex]+1;
		graph(child,vertex);
		height[vertex]=max(height[vertex],height[child]+1);
	}
}
int main(){
int v,e;
cin>>v>>e;
for (int i = 0; i < e; ++i)
{
	int x1,x2;
	cin>>x1>>x2;
	g[x1].push_back(x2);
	g[x2].push_back(x1);
}
graph(1,0);
for (int i = 1; i <= 6; ++i)
{
	cout<<i<<" "<<"D"<<depth[i]<<" "<<"H"<<height[i]<<endl;
}

return 0;
}