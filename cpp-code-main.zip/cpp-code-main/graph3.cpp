#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10;
//bool vi[N];
vector<int>g[N];
//vector<vector<int>>cc;
vector<int>s_sum(N),even_c(N);
void graph(int vertex,int par){
      s_sum[vertex]=vertex;
      if (vertex % 2==0)
       {
       	even_c[vertex]++;
       } 
	for(int child:g[vertex]){
		if (child==par) continue;
		graph(child,vertex);
		s_sum[vertex]+=s_sum[child];
		even_c[vertex]+=even_c[child];
	}
}
int main(){
int v,e;
cin>>v>>e;
for (int i = 0; i < e; ++i)
{
	int x1,x2;
	cin>>x1>>x2;
	g[x1].push_back(x2);
	g[x2].push_back(x1);
}
graph(1,0);
for (int i = 1; i <= 6; ++i)
{
	cout<<i<<" "<<s_sum[i]<<" "<<even_c[i]<<endl;
}

return 0;
}