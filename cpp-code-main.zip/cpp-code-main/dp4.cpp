#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N= 1e5+10;
vector<int>sum(N,0);
int maxi=INT_MIN;
int re(int n){

 if(n==0) return 0;
 if(n==1) return sum[1];

 return max(re(n-1),re(n-2)+sum[n]);
}

int main(){
int n;
	cin>>n;
	int mx=INT_MIN;
	int mini=INT_MAX;
for (int i = 0; i < n; ++i)
{
	int x;
	cin>>x;
	mx=max(mx,x);
	mini=min(mini,x);
	sum[x]+=x;
   

}
cout<<re(mx);

  
  return 0;
}
