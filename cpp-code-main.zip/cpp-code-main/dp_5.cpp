#include<bits/stdc++.h>
using namespace std;
#define ll long long int
void prime_factor(int n,set<ll>&s)
{
	int i=2;
	while((i*i)<=n)
	{
		if(n%i==0)
		{
			s.insert(i);
			n=n/i;
		}
        i++;
	}
	if(n!=0)s.insert(n);

}

int main()
{
 int t;
 cin>>t;
 while(t--)
 {

 	int n;
 	cin>>n;
 	vector<ll>v(n+1);
 	for (int i = 1; i <= n; ++i)
 	{
 		cin>>v[i];
 	}
 	vector<ll>dp(n+1,1);
 	dp[1]=1;
 	for (int j = 2; j <= n; ++j)
 	{
 		if(v[1]<v[j])
 			dp[j]++;
 	}
 	for (int i = 2; i <= n; ++i)
 	{
 		set<ll>s;
 		prime_factor(i,s);
 		for(auto it:s)
 		{
 			ll k=i/it;
 			ll idx=1;
 			while(k>=1)
 			{
 				if (v[i]>v[k])
 			    {
 			    	idx=k;
 				    dp[i]=max(dp[i],(dp[k]+1));
 			    }
 			    // else dp[i]=max(dp[i],(dp[k]));
 			    if(k%it!=0)
 			    {
 			    	
 			      break;
 			    }
 			    k=k/it;
 			}
 					
 		}
 		
 	}

 	ll maxi=*max_element(dp.begin()+1,dp.end());
 	cout<<maxi<<endl;

 } 
  return 0;
}