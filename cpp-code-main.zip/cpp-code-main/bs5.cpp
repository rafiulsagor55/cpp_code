#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N= 1e5+10;
int bs(vector<ll>&arr,ll b){
  
  int lo=1;
  int hi=arr.size();
  int mid;
  while(hi>=lo){
      mid=lo+((hi-lo)/2);
      
       if (arr[mid]>=b)
      {
      	hi=mid-1;
      }
      else{
      	lo=mid+1;
      }


  }

return lo;

}

int main(){
 ll n,m;
 cin>>n>>m;
 vector<ll>arr(n+1);
 
 for (int i = 1; i <= n; ++i)
 {
 	ll x;
 	cin>>x;
 	arr[i]=arr[i-1]+x;
 }
 for (int i = 0; i < m; ++i)
 {
 	ll b;
 cin>>b;

 int num=bs(arr,b);
 ll point=b-arr[num-1];
 cout<<num<<" "<<point<<endl;

 }
 
  return 0;
}