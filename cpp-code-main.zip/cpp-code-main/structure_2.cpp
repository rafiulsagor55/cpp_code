#include<stdio.h>
int main()
{
	typedef struct ad
	{
		char street[20];
		char city[20];
		int zcode;
	}ad;
  
	typedef struct sagor
	{
		ad s1;
		char name[20];
	}sagor;
	sagor s;
	scanf("%[^\n]",s.name);
	getchar();
	scanf("%[^\n]",s.s1.street);
	getchar();
	scanf("%[^\n]",s.s1.city);
	getchar();
	scanf("%d",&s.s1.zcode);
	printf("%s\n%s, %s, %d\n",s.name, s.s1.street,s.s1.city,s.s1.zcode);

	return 0;
}