#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N= 1e5+10;
//vector<int>arr(N);
int main(){
	int t;
	cin>>t;
	while(t--){
     
     ll n;
     cin>>n;

     if (n%2==0 && n<24)
     {
     	cout<<"NO"<<endl;
     }

     else if (n%2 != 0 && n<105)
     {
     	cout<<"NO"<<endl;
     }

     else if (n%2==0)
     {
     	
       ll a=2;
       ll i=3;
       ll b=0,c=0;
       n=n/2;
       while(i*i<=n){
        
        if (n%i==0)
        {
        	b=i;
        	c=n/i;
        	break;
        }
        else i++;

       }
       if (b==c)
       {
       	cout<<"NO"<<endl;
       }
       else {

       	cout<<"YES"<<endl;
       	cout<<a<<" "<<b<<" "<<c<<endl;
       }
     }
     else{

     	ll i=3;
       ll a=0,b=0,c=0;
       while(i*i<=n){
       	if (n%i==0)
       	{
       		a=i;
       		n=n/i;
       		i+=2;
       		break;
       	}
       	else i+=2;
       }
  
      while(i*i<=n){
     if (n%i==0)
       	{
       		b=i;
       		c=n/i;
       		break;
       	}
       	else i+=2;
      }
       if (a==c || b==c)
        {
        cout<<"NO"<<endl;
        } 
        else {
        	cout<<"YES"<<endl;
       	cout<<a<<" "<<b<<" "<<c<<endl;
        }

     }
 }
  return 0;
}
