#include<bits/stdc++.h>
using namespace std;
#define ll long long int
void dfs(int par,vector<int>graph[],vector<ll>&vis)
{
	vis[par]=1;
	for (int child:graph[par])
	{
		
		if(vis[child]==0)
		{
            dfs(child,graph,vis);
		}
		
	}


}
int main()
{
	int n,m;
	cin>>n>>m;
	vector<int>graph[200+1];
	vector<ll>vis(m+1,0);
	set<ll>st;
	ll ans=0;
	for (int i = 1; i <= n; ++i)
	{
		ll k;
		cin>>k;
		if(k==0)ans++;
		vector<ll>v(k+1);
		for (int i = 0; i < k; ++i)
		{
			cin>>v[i];
			st.insert(v[i]);
		}
		for (int i = 0; i < k; ++i)
		{
			for (int j = i+1; j < k; ++j)
			{
				graph[v[i]].push_back(v[j]);
		        graph[v[j]].push_back(v[i]);
			}
		}
	}

	ll cnt=0;
	for (auto it:st)
	{

		if(vis[it])continue;
		dfs(it,graph,vis);
		cnt++;

	}
	if (cnt>0)
	{
		cout<<(ans+cnt-1)<<endl;
	}
	else {
		cout<<ans<<endl;
	}

  return 0;
}