#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N= 1e5+10;
//vector<int>arr(N);
int main(){
	int t;
	cin>>t;
	while(t--){
      ll n,k;
      cin>>n>>k;
      if (k>=n )
      {
      	cout<<"1"<<endl;
      }
      else if (k==1)
      {
      	cout<<n<<endl;
      }
          
     else {
       	int count=0;
       	int i = 2,p,r=0;
   for (; i*i <= n; )
   {
   	if (n%i==0)
   	{ 

      if (i<=k)
      {
        r=i;
      }
      
   		
   		if ((n/i)<=k)
   		{
   			count=1;
        p=i;
   			break;
   		}
   		else i++;
   		
   	}
   	else i++;
   }
    
    if (count==1)
    {
    	cout<<(n/(n/p))<<endl;
    }

    else if (r != 0)
    {
      cout<<(n/r)<<endl;
    }

    else cout<<n<<endl;

       }

        }

  
  return 0;
}
