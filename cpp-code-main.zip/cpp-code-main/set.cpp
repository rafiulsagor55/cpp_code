#include<bits/stdc++.h>
using namespace std;
int main() {
    int t;
    cin>>t;
    for (int i = 0; i < t; ++i)
    {
       int n,k;
       cin>>n>>k;
       vector<int>arr;
       for (int i = 0; i < n; ++i)
       {   int a;
          cin>>a;
          arr.push_back(a);
       }
    vector<int>ans;
    deque<int>q;

     for (int i = 0; i < arr.size(); ++i)
       {
         
         if (!q.empty() && q.front()==(i-k))
           {
               q.pop_front();
           } 

          while(!q.empty() && arr[q.back()]<arr[i]) {
            q.pop_back();
          }  

          q.push_back(i);

         if (i>=(k-1))
         {
             ans.push_back(arr[q.front()]);
         }

       }
    for (int i = 0; i < ans.size(); ++i)
    {
       cout<<ans[i]<<" ";
    }
       ans.clear();
       arr.clear();
       cout<<endl;
    }          
return 0;
}