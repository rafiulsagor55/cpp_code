#include<bits/stdc++.h>
using namespace std;
#define ll long long int
int main()
{

   ll n,m;
   cin>>n>>m;
   vector<set<ll>>s(n+1);
   for (int i = 0; i < m; ++i)
   {
       ll x,y;
       cin>>x>>y;
       s[x].insert(y);
       s[y].insert(x);
       mp[x]++;
       mp[y]++;
   }
   for (int i = 1; i <= n; ++i)
   {
       
   }
  
  return 0;
}
