#include<bits/stdc++.h>
using namespace std;
bitset<103> el[103][103];
int main()
{
	int n,m,a,b,c;
	cin>>n>>m;
	while(m--)
	{
		cin>>a>>b>>c;
		el[a][b].set(c);
		el[b][a].set(c);
	}
	for(int k=1;k<=n;k++)
	  for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)el[i][j]|=(el[i][k]&el[k][j]);
		int q;
	    cin>>q;

	    while(q--)
	    {
	    	cin>>a>>b;
	    	cout<<el[a][b].count()<<"\n";
	    }
}