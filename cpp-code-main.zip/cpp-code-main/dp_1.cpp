#include<bits/stdc++.h>
using namespace std;
#define ll long long int
int main()
{
	ll n,k;
	cin>>n>>k;
	vector<ll>v(n+1);
	for (int i = 1; i <= n; ++i)
	{
		cin>>v[i];

	}
	sort(v.begin()+1,v.end());
	vector<ll>dp(k+1,0);
	dp[0]=1;
	for (int i = 1; i <= k; ++i)
	{
		for (int j = 1; j <= n; ++j)
		{
			if (i>=v[j])
			{
				dp[i]=(dp[i]+dp[i-v[j]])%1000000007;
			}
			
		}
	}
   cout<<dp[k];
  
  return 0;
}
