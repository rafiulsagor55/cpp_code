#include<bits/stdc++.h>
using namespace std;
//vector<int>dp(10000,-1);
int recurPermute(vector<int> &arr,int n,vector<int>&ds,vector<vector<int>>&v) {
         int ans=INT_MIN;
               if(n==0) {
               	ds.push_back(arr[0]);
               	v.push_back(ds);
               	ds.pop_back();
         		
               	return arr[0];
               }
               if(n<0){ 
                v.push_back(ds);
               	return 0;
               }
          	
                
         		ds.push_back(arr[n]);
         		int take=arr[n]+recurPermute(arr,n-2,ds,v);
         		ds.pop_back();
         		int nottake=0+recurPermute(arr,n-1,ds,v);
         		ans=max(take,nottake);
         		
         	
      return ans;
}
    int main(){
	vector<int> arr={2,3,4,-5,-6,4,3,3};
	vector<int> arr1={1,2,3,4,5,6};
	vector<vector<int>>v;
	vector<int>ds;
		
	map<vector<int>,int>mp;
	int x=recurPermute(arr1,arr1.size()-1,ds,v);
	for(auto it: v){
		for(auto itt:it){
			cout<<itt<<" ";
		}
		cout<<endl;
	}
	cout<<x<<endl<<endl;
	// for (int i = 0; i < ds.size(); ++i)
	// {
	// 	cout<<ds[i]<<" ";
	// }

	// int y=recurPermute(arr1,4,ds,v,dp);
	// for(auto it: v){
	// 	for(auto itt:it){
	// 		cout<<itt<<" ";
	// 	}
	// 	cout<<endl;
	// }
	// cout<<y<<endl;

	return 0;
}