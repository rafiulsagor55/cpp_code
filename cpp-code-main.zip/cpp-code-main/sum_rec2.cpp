#include<bits/stdc++.h>
using namespace std;
//vector<int>dp(100,-1);
map<int,int>mp;
map<int,int>mp1;
vector<int>check;
vector<int>check1;
vector<vector<int>>dp(11,vector<int>(11,-1));
int solve(vector<int>&arr,int sum,int n) {
     if (sum==3 && n<0)
     {
     	return 1;
     }
     if (n<0 && sum!=3)
     {
     	return 0;
     }
     // if (n!=0 && sum<=0)
     // {
     // 	return 0;
     // }

      // if(dp[sum][n]!=-1){return dp[sum][n];}

     int ans=solve(arr,sum-arr[n],n-1)+solve(arr,sum+arr[n],n-1);

      	return ans; 
       
}
    int main(){
	vector<int> arr={1,1,1,1,1};
	vector<vector<int>>v;
	vector<int>ds;
	vector<int>freq(arr.size(),-1);
    int ans=solve(arr,0,arr.size()-1);
    cout<<ans<<endl;
    for(auto it:dp){
    	for(auto itt:it){
    		cout<<itt<<" ";
    	}
    	cout<<endl;
    }
	
	
	return 0;
}