#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10; 
vector<int>dp(N,-1);
vector<int>vi(N,-1);
vector<int>h(N,0);

int re(int n,int m,int p){
    cout<<n<<endl;
	if (n==m) return 0;
	if (vi[n]==1)
	{
		return 0;
	}
	//if(n>m) return 0;
	//if(n<m) return 0;
	//if(dp[n]!= -1) return dp[n];
	
	int mini=INT_MAX;
	//cout<<n<<endl;
	if (vi[n]==-1 && n>0)
	{       vi[n]=1;
			mini=min(mini,(re(( n-1),m,p)+1));
			if (n<m)
				{
					 mini=min(mini,(re((n*2),m,p)+1));
				}	
	       	
	}
    return  mini;
}
    int main(){
	int n,m;
	cin>>n>>m;
	cout<<re(n,m,n);
	return 0;
}