#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10;
//bool vi[N];
vector<int>g[N];
//vector<vector<int>>cc;
vector<int>depth(N);
void graph(int vertex,int par=0){
      
	for(int child:g[vertex]){
		if (child==par) continue;
		depth[child]=depth[vertex]+1;
		graph(child,vertex);
	}
}
int main(){
int v,e;
cin>>v>>e;
for (int i = 0; i < e; ++i)
{
	int x1,x2;
	cin>>x1>>x2;
	g[x1].push_back(x2);
	g[x2].push_back(x1);
}
graph(1);
int max_d=-1;
int max_n;
for (int i = 1; i <= 8; ++i)
{
	if (depth[i]>max_d)
	{
		max_d=depth[i];
		max_n=i;

	}
	depth[i]=0;
}
cout<<max_d<<" "<<max_n;
cout<<endl;
graph(max_n);
int max_d1=-1;
int max_n1;
for (int i = 1; i <= 8; ++i)
{
	if (depth[i]>max_d1)
	{
		max_d1=depth[i];
		max_n1=i;
		
	}

}
cout<<max_d1<<" "<<max_n1;
cout<<endl;
return 0;
}