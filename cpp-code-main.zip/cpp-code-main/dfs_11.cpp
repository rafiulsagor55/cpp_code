#include<bits/stdc++.h>
using namespace std;
#define ll long long int
int f=0;
void dfs(int par,vector<int>graph[],vector<ll>&vis,vector<ll>&dp,map<pair<ll,ll>,ll>&m)
{
	vis[par]=1;
    
	for (int child:graph[par])
	{
		
		if(vis[child]==0)
		{
            dp[par]++;
            if(f==1)
            {
            	m[{child,par}]=5;
            	m[{par,child}]=5;
                f=0;
            }
            else
            {
                m[{child,par}]=2;
            	m[{par,child}]=2;
                f=1;
            }
            dfs(child,graph,vis,dp,m);
            

		}
		
		
	}


}

int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		int n;
		cin>>n;
		vector<int>graph[n+1];
		vector<pair<ll,ll>>pr;
		for (int i = 1; i <= n-1; ++i)
		{
			int x,y;
			cin>>x>>y;
			pr.push_back({x,y});
			graph[x].push_back(y);
			graph[y].push_back(x);
		}
		
		vector<ll>dp(n+3,0);
		vector<ll>vis(n+3,0);
		map<pair<ll,ll>,ll>m;
        dfs(1,graph,vis,dp,m);
        int flag=0,idx;
        if(dp[1]>2)flag=1;
        for (int i = 2; i <= n; ++i)
        {
        	if(dp[i]>1)flag=1;
        	if(dp[i]==0)idx=i;

        }
        vector<ll>vi(n+3,0);
        map<pair<ll,ll>,ll>mp;
        f=0;
        dfs(idx,graph,vi,dp,mp);
        if (flag==1)
        {
        	cout<<"-1"<<endl;
        }
        else
        {
             for (int i = 0; i < n-1; ++i)
             {
             	cout<<mp[{pr[i].first,pr[i].second}]<<" ";
             }
             cout<<endl;
        }
	
    }
	
 
  return 0;
}