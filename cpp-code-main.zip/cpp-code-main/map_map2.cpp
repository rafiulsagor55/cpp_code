#include<bits/stdc++.h>
using namespace std;
#define ll long long
int main()
{
	
	int n;
	cin>>n;
	ll a,b,c;
	

	map<pair<ll,ll>,map<ll,ll>>ab2;
	for (int i = 0; i < n; ++i)
	{
		cin>>a>>b>>c;
		ab2[{a,b}][c]++;

	}
    
    ll p,q,r;
    for (int i = 0; i < n; ++i)
    {
    	cout<<ab2[{p,q}][r];
    }
   
  
  return 0;
}
