#include<bits/stdc++.h>
using namespace std;
void re(vector<int>&arr,int inx,int n,int k,int sum,vector<int>&temp,vector<vector<int>>&v){
    
	if (inx==n)
	{
		if (sum==k)
		{
			v.push_back(temp);
			
		}
		return;
		
		
	}
temp.push_back(arr[inx]);
re(arr,inx+1,n,k,sum+arr[inx],temp,v);
temp.pop_back();
// sum-=arr[inx];
re(arr,inx+1,n,k,sum,temp,v);
// temp.pop_back();

}

int main(){
	vector<int> arr={1,1,2,5,6,7,10};
	vector<vector<int>>v;
	vector<int>temp;
	re(arr,0,6,8,0,temp,v);
	for(auto it: v){
		for(auto itt:it){
			cout<<itt<<" ";
		}
		cout<<endl;
		
	}

	return 0;
}