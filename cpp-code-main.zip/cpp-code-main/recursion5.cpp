#include<bits/stdc++.h>
using namespace std;
vector<vector<int>>dp(100,vector<int>(100,-1));
int recurPermute(vector<int> &arr,vector<int> &arr1,int sum,int n,vector<int>&ds,vector<vector<int>>&v,vector<int>&freq) {
         
          
          	if (n==0)
          	{
          		
          		if (sum>=arr[0])
          		{
          			v.push_back(ds);
          			return arr1[0];
          		}
          		 else{ 
          		 	v.push_back(ds);
          		 	return 0;
          		 }
          	}
          	
          	if(dp[n][sum]!=-1){
         	   return dp[n][sum];
         		}
         
           int take=0;
           if (sum>=arr[n])
           {
           	ds.push_back(arr[n]);
           	take=recurPermute(arr,arr1,sum-arr[n],n-1,ds,v,freq)+arr1[n]+0LL;
           	ds.pop_back();
           }
           int nottake=recurPermute(arr,arr1,sum,n-1,ds,v,freq)+0LL;
          dp[n][sum]= max(take,nottake);
          return dp[n][sum];
}
   int main(){
	vector<int> arr={1,2,1,4,5,1,1,1,1,2,1};
	vector<int> arr1={5,4,5,1,6,4,5,6,7,1,1};
	vector<vector<int>>v;
	vector<int>ds;
	vector<int>freq(arr.size(),-1);
	//int mx=99999;
	map<vector<int>,int>mp;
	int x=recurPermute(arr,arr1,5,arr.size()-1,ds,v,freq);
	//cout<<x<<endl;
	for(auto it: v){
		for(auto itt:it){
			cout<<itt<<" ";
		}
		cout<<endl;
	}
	cout<<x<<endl;
	//cout<<INT_MAX;

	return 0;
}