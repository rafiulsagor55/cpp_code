#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N= 1e5+10;
int main(){
	string s;
	cin>>s;
	int x=s[s.size()-1]-'0';
	int cnt=0;
	for (int i = 0; i < s.size()-1; ++i)
	{
		int y=s[i]-'0';
		if (x>y && y%2==0)
		{
			char ch=s[i];
			s[i]=s[s.size()-1];
			s[s.size()-1]=ch;
			cnt=1;
			break;
		}
	}
	int cnt1=0;
	if (cnt==0)
	{
		for (int i = s.size()-2; i >=0;--i)
		{
			int y=s[i]-'0';
			if (y%2==0)
			{
				char ch=s[i];
			    s[i]=s[s.size()-1];
			    s[s.size()-1]=ch;
			    cnt1=1;
			     break;
			}
		}
	}
	if (cnt==0 && cnt1==0)
	{
		cout<<"-1"<<endl;
	}
	else{
		cout<<s<<endl;
	}

   
  return 0;
}
