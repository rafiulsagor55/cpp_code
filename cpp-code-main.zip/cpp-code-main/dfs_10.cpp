#include<bits/stdc++.h>
using namespace std;
#define ll long long int

void dfs(int par,vector<int>graph[],vector<ll>&vis,vector<ll>&w,vector<ll>&b,string &s)
{
	vis[par]=1;
	for (int child:graph[par])
	{
		
		if(vis[child]==0)
		{
            dfs(child,graph,vis,w,b,s);
            w[par]+=w[child];
			b[par]+=b[child];

		}
		
		
	}


}

int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		int n;
		cin>>n;
		vector<int>graph[n+1];
		for (int i = 2; i <= n; ++i)
		{
			int x;
			cin>>x;
			graph[x].push_back(i);
			graph[i].push_back(x);
		}
		string s;
		cin>>s;
		vector<ll>w(n+3,0);
		vector<ll>b(n+3,0);
		vector<ll>vis(n+3,0);
		for (int i = 1; i <=n; ++i)
		{
			if (s[i-1]=='W')
			{
				w[i]=1;

			}
			else if (s[i-1]=='B')
			{
				b[i]=1;
			}
		}
        dfs(1,graph,vis,w,b,s);
        int cnt=0;
		for (int i = 1; i <= n; ++i)
		{
			if(b[i]==w[i])cnt++;
		}		
		cout<<cnt<<endl;
	
    }
	
 
  return 0;
}