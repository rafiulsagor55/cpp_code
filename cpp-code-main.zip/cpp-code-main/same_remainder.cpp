#include<bits/stdc++.h>
using namespace std;
#define ll long long int
int main()
{
 int t;
 cin>>t;
 while(t--)
 {
    ll n;
    cin>>n;
    vector<ll>v;
    int zero=0,ones=0;
    for (int i = 0; i < n; ++i)
    {
    	ll x;
    	cin>>x;
    	v.push_back(x);
        if(x==0)zero++;
        if(x==1)ones++;
    }
    sort(v.begin(),v.end());
    ll flag=0;
    for (int i = 1; i < n; ++i)
    {
    	if ((v[i]-v[i-1])==1)
    	{
    		flag=1;
    		break;
    	}
    }
    if (zero>=1 && ones>=1)
    {
    	cout<<"NO"<<endl;
    }
    else if (flag==1 && ones>=1)
    {
    	cout<<"NO"<<endl;
    }
    else cout<<"YES"<<endl;

 } 
  return 0;
}