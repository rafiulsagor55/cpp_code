#include<bits/stdc++.h>
using namespace std;
vector<int>dp(10000,-1);
int recurPermute(vector<int> &arr,int sum,vector<int>&ds,vector<vector<int>>&v,vector<int>&freq) {
         
          
          	if (sum==0)
          	{
          		v.push_back(ds);
          		return 0;
          	}
          	if(dp[sum]!=-1){
         	   return dp[sum];
         		}
         	if (sum<0)
         	{
         		return 0;
         	}
          int ans=INT_MAX;
         for (int i = 0; i < arr.size(); ++i)
         {

         	if (freq[i]==-1)

         	{
         		freq[i]=1;
         		ds.push_back(arr[i]);
         		ans=min(ans+0LL,(recurPermute(arr,sum-arr[i],ds,v,freq)+1LL));       		
         		ds.pop_back();
         		freq[i]=-1;

         	}
         }
       return dp[sum]=ans;
}
    int main(){
	vector<int> arr={1,3,2,5,4,7,6,9,8};
	vector<vector<int>>v;
	vector<int>ds;
	vector<int>freq(arr.size(),-1);
	//int mx=99999;
	map<vector<int>,int>mp;
	int x=recurPermute(arr,8,ds,v,freq);
	//cout<<x<<endl;
	for(auto it: v){
		for(auto itt:it){
			cout<<itt<<" ";
		}
		cout<<endl;
	}
	cout<<x<<endl;
	//cout<<INT_MAX;

	return 0;
}