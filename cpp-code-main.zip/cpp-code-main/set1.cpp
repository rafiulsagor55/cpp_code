#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N= 1e5+10;
//vector<int>arr(N);
int main(){
 int t;
 cin>>t;
 while(t--){
 	int n;
 	cin>>n;
 	vector<set<int>>v;
  set<int>s;
 	for (int i = 0; i < n; ++i)
 	{
 		int m;
 		cin>>m;
 		set<int>st;
 		for (int i = 0; i < m; ++i)
 		{
 			int x;
 			cin>>x;
 			st.insert(x);
      s.insert(x);
 			
 		}
 		v.push_back(st);
 		st.clear();
 		
 	}
   int mx=INT_MIN;
   for(auto it:s){
    set<int>st;
    for(auto itt:v){
      if (itt.count(it)==0)
      {
        for(auto ittt:itt){
          st.insert(ittt);
        }
      }
    }
    mx=max(mx,(int)st.size());
   }
   cout<<mx<<endl;

 } 
  return 0;
}