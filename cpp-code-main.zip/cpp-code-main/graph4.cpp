#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10;
vector<int>g[N];
vector<int>p(N);
void graph(int vertex,int par=-1){
      p[vertex]=par;
	for(int child:g[vertex]){
		if (child==par) continue;
		graph(child,vertex);
	}
}
vector<int>path(int v){
	vector<int>temp;
	while(v != -1){
		temp.push_back(v);
		v=p[v];
	}
	reverse(temp.begin(),temp.end());
	return temp;
}
int main(){
int v,e;
cin>>v>>e;
for (int i = 0; i < e; ++i)
{
	int x1,x2;
	cin>>x1>>x2;
	g[x1].push_back(x2);
	g[x2].push_back(x1);
}
graph(1);
int x,y;
cin>>x>>y;
vector<int>path_1=path(x);
vector<int>path_2=path(y);
int l=min(path_1.size(),path_2.size());
 int lca=-1;
  for (int i = 0; i < l; ++i)
  {
  	if (path_1[i]==path_2[i])
  	{
  		lca=path_1[i];
  	}
  	else break;
  }
cout<<lca;

return 0;
}