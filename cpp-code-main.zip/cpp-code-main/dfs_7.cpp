#include<bits/stdc++.h>
using namespace std;
#define ll long long int
void dfs(int curr,int par,vector<pair<int,int>>g[],vector<int>&vis,vector<int>&dp,map<pair<int,int>,int>&mp)
{
	vis[curr]=1;
	for (auto child:g[curr])
	{
		
		if(vis[child.first]==0)
		{
			// int ver=child.first;
			// int pos=child.second;
			// mp[{ver,curr}]=pos;
			// mp[{curr,ver}]=pos;
			
				// if (mp[{par,curr}]<pos)
                // {
            	//    // dp[ver]=dp[curr];
                // }
                // else
                // {
            	//    // dp[ver]=dp[curr]+1;
                // }
                dfs(child.first,curr,g,vis,dp,mp);
		

		}
		
	}


}
int main()
{
 int t;
 cin>>t;
 while(t--)
 {
 	int n;
 	cin>>n;
 	vector<pair<int,int>>g[n];
 	for (int i = 1; i < n; ++i)
 	{
 	    int x,y;
 	    cin>>x>>y;
 	    g[x].push_back({y,i});
 	    g[y].push_back({x,i});
 	}
 	vector<int>dp(n+1,-1);
 	vector<int>vis(n+1,0);
 	dp[0]=1,dp[1]=1;
 	map<pair<int,int>,int>mp;
    dfs(1,-1,g,vis,dp,mp);
    // int mx=*max_element(dp.begin(),dp.end());
     
     // cout<<mx<<endl;



 } 
  return 0;
}