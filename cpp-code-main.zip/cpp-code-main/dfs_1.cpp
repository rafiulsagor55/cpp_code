#include<bits/stdc++.h>
using namespace std;
#define ll long long int
void dfs(int par,ll &mn,vector<int>graph[],vector<ll>&vis,vector<ll>&v)
{
	vis[par]=1;
	mn=min(v[par],mn);
	for (int child:graph[par])
	{
		
		if(vis[child]==0)
		{
            dfs(child,mn,graph,vis,v);
		}
		
	}


}
int main()
{
	int n,m;
	cin>>n>>m;
	vector<int>graph[n+1];
	vector<ll>vis(n+1,0);
	vector<ll>v(n+1);
	for (int i = 1; i <= n; ++i)
	{
		cin>>v[i];
	}
	for (int i = 0; i < m; ++i)
	{
		int x,y;
		cin>>x>>y;
		graph[x].push_back(y);
		graph[y].push_back(x);
	}
	ll ans=0;
    ll mn=99999999999;
	for (int i = 1; i <= n; ++i)
	{

		if(vis[i])continue;
		dfs(i,mn,graph,vis,v);
		ans+=mn;

		// cout<<mn<<endl;
		mn=99999999999;
	}
	// cout<<graph[2];
	
	cout<<ans<<endl;
	
 
  return 0;
}