#include<bits/stdc++.h>
using namespace std;
vector<int>dp(100,-1);
map<int,int>mp;
map<int,int>mp1;
vector<int>check;
vector<int>check1;
int solve(vector<int>&arr,int sum,vector<int>&ds,vector<vector<int>>&v,vector<int>&freq) {
        
        if (sum==0)
        {
            dp[sum]=0;
        	v.push_back(ds);
        	return 0;

        }

        if (sum<0)
        {
        	return INT_MIN;
        }
        
        int mx=INT_MIN,take=0;
        for (int i = 0; i < arr.size(); ++i)
        {
        	if (freq[i]==-1){
        	    freq[i]=1;
        		ds.push_back(arr[i]);
       		 mx=max(solve(arr,sum-arr[i],ds,v,freq)+1,mx);
        	
        		ds.pop_back();
        		freq[i]=-1;
        		
        	}
        	
        }
          
          
          return mx;
}
    int main(){
	vector<int> arr={4,3,2,1,1};
	vector<vector<int>>v;
	vector<int>ds;
	vector<int>freq(arr.size(),-1);

	int x=solve(arr,8,ds,v,freq);
	for(auto it: v){
		for(auto itt:it){
			cout<<itt<<" ";
		}
		cout<<endl;
	}
	cout<<x<<endl<<endl;
	for (int i = 0; i < 20; ++i)
	{
		cout<<dp[i]<<" ";
	}
	
	for (int i = 0; i < check.size(); ++i)
	{
		cout<<check[i]<<" "<<check1[i]<<endl;
	}
	
	return 0;
}