#include<bits/stdc++.h>
using namespace std;
#define ll long long int
vector<int>path(100,0);
vector<int>vis(100,0);
void bfs(int par,vector<pair<int,int>>g[])
{
     set<pair<int,int>>q;
     q.insert({0,par});
     while(!q.empty())
     {
     	pair<int,int>parn=*(q.begin());
        int par_1=parn.second;
     	vis[par_1]=1;
     	q.erase(q.begin()); 
         for(auto it:g[par_1])
         {
         	if (vis[it.first]==0)
         	{
         		int child=it.first;
         	    int wt=it.second;
                if (path[child]!=0)
                {
                    path[child]=min(path[child],(path[par_1]+wt));
                }
         	    else path[child]=path[par_1]+wt;
         	    q.insert({path[child],child});
         	    // cout<<child<<" "<<path[child]<<endl;
         	}        	
         	        	
         }
     }

}
int main()
{

    int n;
    cin>>n;
    vector<pair<int,int>>g[n+1];
    for (int i = 0; i < n; ++i)
    {
    	int x,y,wt;
    	cin>>x>>y>>wt;
    	g[x].push_back({y,wt});
    	g[y].push_back({x,wt});

    }

   bfs(1,g);
  for (int i = 1; i < 9; ++i)
  {
      cout<<i<<" "<<path[i]<<endl;
  }

 
  return 0;
}