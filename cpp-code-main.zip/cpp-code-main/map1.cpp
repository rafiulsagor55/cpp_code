#include<bits/stdc++.h>
using namespace std;
int main()
{
 vector<long long>arr,arr1(10000000,0);
 vector<long long>arr2(10000000,0);   
 long long x=INT_MAX;
 long long p;
 while(cin>>p && p!=0)
  { 
      arr.push_back(p);
     x= min(x,p);
  }
long long x1=abs(x);
for (long long i = 0; i < arr.size(); ++i)
{
    arr1[(arr[i]+x1)]++;

}
 for (long long i = 0; i < arr.size(); ++i)
  {
     if (arr2[(arr[i]+x1)]==0)
     {
        cout<<(arr[i])<<" "<<arr1[arr[i]+x1]<<endl;
     }
      
     arr2[(arr[i]+x1)]++;
  } 
 
return 0;
}