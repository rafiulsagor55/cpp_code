#include<bits/stdc++.h>
using namespace std;
int main()
{ 
 map<string,string>mp;
 string s,s1,s2;
 while(getline(cin,s) && !s.empty()){
 	stringstream pp(s);
 	pp>>s1>>s2;
  mp.insert({s2,s1});
 }
 string s3;
 while(cin>>s3){
 	string s4=mp[s3];
 	if (s4.empty())
 	{
 		cout<<"eh"<<endl;
 	}
 	else cout<<s4<<endl;
 }



return 0;
}