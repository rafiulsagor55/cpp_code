#include<bits/stdc++.h>
using namespace std;
#define ll long long int
int main()
{
	ll n,k;
	cin>>n>>k;
	vector<pair<ll,ll>>pr;
	vector<ll>v;
	for (int i = 0; i < n; ++i)
	{
		ll x;
		cin>>x;
		v.push_back(x);
	}
	for (int i = 0; i < n; ++i)
	{
		ll x;
		cin>>x;
		pr.push_back({v[i],x});
	}
	map<ll,ll>mp;
	vector<ll>dp(k+1,-1);
	dp[0]=0;
	ll mx=-1;
	for (int i = 1; i <= k; ++i)
	{
		for (int j = 0; j < n; ++j)
		{
            if (i>=pr[j].first )
            {
            	dp[i]=max(dp[i],dp[i-pr[j].first]+pr[j].second);
			    mx=max(mx,dp[i]);
			    mp[j]=1;
            }
			
		}

	}
	cout<<mx;
  
  return 0;
}
