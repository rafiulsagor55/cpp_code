#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10; 
//vector<int>dp(N,-1);
vector<int>vi(N,-1);
vector<int>g[N];
vector<int>depth(N),height(N);
void graph(int vertex,int par){ 
   for(int child:g[vertex]){
      if (child==par) continue;
      depth[child]=depth[vertex]+1;
      graph(child,vertex);
      
   }
}

int main()
{	
 int n,m;
 cin>>n>>m;
 deque<int>q;
 q.push_back(n);
 int count=0;
 while(!q.empty()){
 	int x=q.front();
    //cout<<x<<endl;
    q.pop_front();
 	if(vi[x] ==-1){ 
    if (x>1)
     {  
     	if (vi[x-1] ==-1)
     	{
     		q.push_back((x-1));
     		g[x].push_back(x-1);
     	}
     	
     } 
     if (x<=m)
     {
     	if (vi[x*2] ==-1)
     	{
     		q.push_back((x*2));
     		g[x].push_back(x*2);
     	}
     }
     
      vi[x]=1;
   }

    if(x==m) break;
 }  
  graph(n,0);
  cout<<depth[m];
	return 0;
}