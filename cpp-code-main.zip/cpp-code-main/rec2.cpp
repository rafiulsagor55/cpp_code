#include<bits/stdc++.h>
using namespace std;
void re(vector<int>&arr,int inx,int n,vector<int>&temp,vector<vector<int>>&v){   
	if (inx==n)
	{
		v.push_back(arr);	
		return;
	}
	for (int i = inx; i < n; ++i)
	{
		swap(arr[i],arr[inx]);
		cout<<i<<" "<<inx;
		cout<<endl;
		re(arr,inx+1,n,temp,v);
		swap(arr[i],arr[inx]);
        cout<<i<<" "<<inx;
        cout<<endl;
	}
}
int main(){
	vector<int> arr={1,2,3,4};
	vector<vector<int>>v;
	vector<int>temp;
	re(arr,0,4,temp,v);
	for(auto it: v){
		for(auto itt:it){
			cout<<itt<<" ";
		}
		cout<<endl;
		
	}
	return 0;
}
