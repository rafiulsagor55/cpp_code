#include<stdio.h>
int main()
{
	typedef struct sagor
	{
		char name[20];
		int roll;
		int number;
	}sagor;
	sagor s[10];
	sagor *ptr=&s[0];
	// (ptr+1)->roll=10;
	scanf("%[^\n]",(ptr+1)->name);
	getchar();
	scanf("%d%d",&(ptr+1)->roll,&(ptr+1)->number);
	printf("%d %d %s\n", (ptr+1)->roll,(ptr+1)->number,(ptr+1)->name);


	return 0;
}