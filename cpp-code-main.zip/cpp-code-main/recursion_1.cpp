#include <bits/stdc++.h>
#define ll long long int
using namespace std;
ll solve(int idx, vector<ll>&arr, ll sum1,ll sum)
{
    // If we have reached the end, return the difference
    // between the sums
    if (idx == arr.size()) 
    {
        return abs(sum1 - (sum-sum1));
    }

    // Choose the current apple in group 1
    ll choose = solve(idx + 1, arr, sum1 + arr[idx], sum);

    // Choose the current apple in group 2
    ll notChoose = solve(idx + 1, arr, sum1, sum);

    // Return the minimum of both the choices
    return min(choose, notChoose);
}

int main()
{
    // Sample Input
    ll n;
    cin>>n;
    vector<ll>arr;
    ll sum=0;
    for (int i = 0; i < n; ++i)
    {
        ll x;
        cin>>x;
        arr.push_back(x);
        sum+=x;
    }

    ll ans = solve(0, arr, 0, sum);
    cout << ans;
}