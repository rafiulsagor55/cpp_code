#include<bits/stdc++.h>
using namespace std;
int main()
{ 
vector<long long>arr;
map<long long,long long >mp;
set<int> st;
int t;
cin>>t;
for (int i = 0; i < t; ++i)
{
	long long p;
	cin>>p;
	arr.push_back(p);
	st.insert(p);
	mp[p]++;
}
   long long ans=0;
   for(int it=0; it<arr.size();++it){
   	
   		ans+=(arr.size()-mp[arr[it]]);
   		
 }
 cout<<ans/2;


return 0;
}