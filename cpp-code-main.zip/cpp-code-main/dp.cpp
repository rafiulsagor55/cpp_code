#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10; 
vector<int>dp(N,-1);
int re(int n,int m,int p){
    //cout<<p<<" ";
    cout<<n<<endl;
	if (n==m) return 0;
	//if(n==0) return 0;
	//if(n>m) return 0;
	//if(n<m) return 0;
	if(dp[n]!= -1) return dp[n];
	int mini=INT_MAX;
	
	if (n>1 n<(m/) && (p!=(n-1)))
	{
			mini=min(mini,(re(( n-1),m,p)+1));
		
	}
	
	if (n<m && p !=(n*2) )
	{
	       mini=min(mini,(re((n*2),m,p)+1));	
	}
    return dp[n]= mini;
}
    int main(){
	int n,m;
	cin>>n>>m;
	cout<<re(n,m,n);
	return 0;
}
