#include<bits/stdc++.h>
using namespace std;
#define ll long long int
ll ans(ll m,ll n)
{
   ll sum=0;
   while(n>0)
   {
   	  if(n<m)
   	  {
   	  	 sum+=n;
   	  	 n=0;
   	  }
   	  else
   	  {
   	  	 sum+=m;
   	  	 n-=m;
   	  }
   	  if (n>=10)
   	  {
   	  	  ll x=((10)*n)/100;
   	  	  n-=x;
   	  }
   }
   return sum;
}
ll bs(ll l,ll h,ll n)
{
	ll m,mid;
	while(l<=h)
	{
		m=l+(h-l)/2;
		ll sum=ans(m,n);
		ll p;
		if(n%2==0)p=n/2;
		else p=(n/2)+1;
		if (sum>=p)
		{
			mid=m;
			h=m-1;
		}
		else if (sum<p)
		{
			l=m+1;
		}
	}
	return mid;
}
int main()
{
	ll n;
	cin>>n;
	ll l=1;
    ll ans=bs(l,n,n);
    cout<<ans<<endl;
  
  return 0;
}
