#include<bits/stdc++.h>
using namespace std;
#define ll long long int
int main()
{
 int t;
 cin>>t;
 while(t--)
 {
 	ll n,k;
 	cin>>n>>k;
 	vector<ll> v;
 	for (int i = 0; i < n; ++i)
 	{
 		ll x;
 		cin>>x;
 		v.push_back(x);
 	}
 	sort(v.begin(),v.end());
 	priority_queue<ll>pq;
 	ll ans=0;
 	for (int i = n-1; i >= 0; i--)
 	{
 		pq.push(-v[i]);
 		ll y=-(pq.top());
 		ll size=pq.size();
 		if((y*size)>=k)
 		{
 			ans++;
 			priority_queue<ll>pq1;
 			pq=pq1;
 		}
 	}

    cout<<ans<<endl;

 } 
  return 0;
}