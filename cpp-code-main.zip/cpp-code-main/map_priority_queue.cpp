#include<bits/stdc++.h>
using namespace std;
#define ll long long int
int main(){
 int t;
 cin>>t;
 while(t--){
 	int n;
 	cin>>n;
 	vector<pair<ll,ll>>pr;
    map<int,priority_queue<ll>>p_map;
 	for (int i = 0; i < n; ++i)
 	{
 		ll a,b;
 		cin>>a>>b;
 		p_map[a].push(b);

 	}
 	
 	// for (int i = 0; i < pr.size(); ++i)
 	// {
 	// 	 if (pr[i].first ==pr[i+1].first)
 	// 	{
 	// 		p.push(pr[i].second);
 	// 	}
 	// 	else
 	// 	{
 	// 		p.push(pr[i].second);
 	// 		p_map[pr[i].first]=p;
 	// 		priority_queue<int>pi;
 	// 		p=pi;


 	// 	}
 	// }
    
    ll ans=0;
    for (auto it:p_map)
    {
    	int cnt=0;
    	int x=it.first;
    	// priority_queue<int>q=it.second;
    	while(x-- && !it.second.empty())
    	{
    		ans+=it.second.top();
    		it.second.pop();
    		
    	}

    }

    cout<<ans<<endl;


 } 
  return 0;
}