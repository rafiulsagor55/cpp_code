#include<bits/stdc++.h>
using namespace std;
#define ll long long int
int main(){
 int t;
 cin>>t;
 while(t--){
 	int n;
 	cin>>n;
 	string s1,s2;
 	cin>>s1>>s2;
 	ll cnt=0;
 	vector<ll>v;
 	for (int i = n-1; i >=0; --i)
 	{
 		if (s1[i]!=s2[i])
 		{
 			if (s1[i]==s1[0])
 			{
 				v.push_back(i);
 				for (int j = 0; j <= i; ++j)
 				{
 					if (s1[j]=='0')
 					{
 						s1[j]='1';
 					}
 					else
 					{
 						s1[j]='0';
 					}
 				}
 				int r1=0,r2=i;
 				while(r1<r2)
 				{
 					char ch=s1[r1];
 					s1[r1]=s1[r2];
 					s1[r2]=ch;
 					r1++;
 					r2--;

 				}
 			}
 			else
 			{
 				v.push_back(i);
 				v.push_back(0);
 				v.push_back(i);
 				for (int j = 0; j <= i; ++j)
 				{
 					if (s1[j]=='0')
 					{
 						s1[j]='1';
 					}
 					else
 					{
 						s1[j]='0';
 					}
 				}
 				int p1=0,p2=i;
 				while(p1<p2)
 				{
 					char ch=s1[p1];
 					s1[p1]=s1[p2];
 					s1[p2]=ch;
 					p1++;
 					p2--;

 				}

 				    if (s1[0]=='0')
 					{
 						s1[0]='1';
 					}
 					else
 					{
 						s1[0]='0';
 					}
 				for (int j = 0; j <= i; ++j)
 				{
 					if (s1[j]=='0')
 					{
 						s1[j]='1';
 					}
 					else
 					{
 						s1[j]='0';
 					}
 				}
 				int q1=0,q2=i;
 				while(q1<q2)
 				{
 					char ch=s1[q1];
 					s1[q1]=s1[q2];
 					s1[q2]=ch;
 					q1++;
 					q2--;

 				}


 			}
 		}
 	}
    // cout<<s1<<endl;
    cout<<v.size()<<" ";

    for (int i = 0; i < v.size(); ++i)
    {
    	cout<<v[i]+1<<" ";
    }
    cout<<endl;

 } 
  return 0;
}