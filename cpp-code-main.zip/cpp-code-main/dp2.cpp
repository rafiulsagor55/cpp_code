#include<bits/stdc++.h>
using namespace std;
const int N=1e6+10;
bool vi[N];

//vector<vector<int>>cc;
//vector<int>c_cc;
vector<int>dp(N,-1);

int re(int sum){ 
	
   
    bool isloop=0;
		if (0>sum) return 0;
		if (0==sum) return 1;
		if(dp[sum]==0) return 0;
		if(dp[sum]==1) return 1;
		isloop|=re(sum-2020)|re(sum-2021);
		
return dp[sum]=isloop;
}
int main()
{
	
   int t;
   cin>>t;
   for (int i = 0; i < t; ++i)
   {
   	int x;
   	cin>>x;
   	if(re(x))cout<<"YES"<<endl;
   	else cout<<"NO"<<endl;
   	
   }


	return 0;
}