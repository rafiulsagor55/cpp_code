#include<bits/stdc++.h>
using namespace std;
vector<vector<int>>dp(100,vector<int>(100,-1));
// vector<int>dp(2005,-1);
int recurPermute(vector<int>&arr,int idx,int sum,vector<int>&ds,vector<vector<int>>&v) 
{
	 if (idx==arr.size())
	         {
	         	v.push_back(ds);
	         	return 0;
	         }    

	  if (dp[idx][sum]!=-1)
	      {
	      	return dp[idx][sum];
	      }    
                      
     int take=0;
     if ((sum+arr[idx])>=0)
     {
     ds.push_back(arr[idx]);
     take=1+recurPermute(arr,idx+1,sum+arr[idx],ds,v);
     ds.pop_back();
     }
     
      int nottake=recurPermute(arr,idx+1,sum,ds,v);              
      return dp[idx][sum]=max(take,nottake);    
}     
int main()
{
	vector<int> arr={4,-4,1,-3,1,-3};
	vector<vector<int>>v;
	vector<int>ds;
		
	map<vector<int>,int>mp;
	int x=recurPermute(arr,0,0,ds,v);
	for(auto it: v){
		for(auto itt:it){
			cout<<itt<<" ";
		}
		cout<<endl;
	}
	cout<<x<<endl<<endl;
	

	return 0;
}