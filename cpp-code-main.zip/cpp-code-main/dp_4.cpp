#include<bits/stdc++.h>
using namespace std;
#define ll long long int
int main()
{
  ll n;
  cin>>n;
  vector<pair<ll,ll>>pr;
  for (int i = 0; i < n; ++i)
  {
     ll x,y;
     cin>>x>>y;
     pr.push_back({x,y});
  }
  ll l=pr[0].first;
  ll ans=2;
  for (int i = 1; i < n-1; ++i)
  {
      ll cp=pr[i].first;
      ll h=pr[i].second;
      if((l+h)<cp)
      {
          ans++;
          l=cp;
      }
      else if((cp+h)<(pr[i+1].first))
      {
         ans++;
         l=cp+h;
      }
      else
      {
        l=pr[i].first;
      }

  }
  if(n==1)cout<<"1"<<endl;
  else cout<<ans<<endl;
  
  return 0;
}
