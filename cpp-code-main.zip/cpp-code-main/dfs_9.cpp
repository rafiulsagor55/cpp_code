#include<bits/stdc++.h>
using namespace std;
#define ll long long int

void dfs(int par,ll &node,vector<int>graph[],vector<ll>&vis,vector<ll>&dp)
{
	vis[par]=1;
	node++;
	for (int child:graph[par])
	{
		
		if(vis[child]==0)
		{
            dfs(child,node,graph,vis,dp);
		}
		
	}
	dp[par]=node;


}

int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		int n;
		cin>>n;
		vector<int>graph[n+1];
		for (int i = 1; i <= n; ++i)
		{
			int x;
			cin>>x;
			graph[x].push_back(i);
			graph[i].push_back(x);
		}
		vector<ll>dp(n+1,-1);
		for (int i = 1; i <= n; ++i)
		{
			if (dp[i]==-1)
			{
				ll node=0;
			    vector<ll>vis(n+1,0);
			    dfs(i,node,graph,vis,dp);
			}
		
		    cout<<dp[i]<<" ";			
		}
		
		cout<<endl;
	
    }
	
 
  return 0;
}