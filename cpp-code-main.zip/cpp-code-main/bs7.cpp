#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N= 1e5+10;
 
 ll is_sum(ll k,vector<ll>&arr,ll mid){

 	 ll mn=LONG_MIN;
 	 ll sum=0;

     for (int i = 0; i < arr.size()-1; ++i)
     {
     	ll x1=arr[i],x2=arr[i+1];
     	ll y=x2-x1;
     	mn=min(mid,y);
     	sum+=mn;
     }
   sum+=mid;
   return sum;
 }

int main(){
 int t;
 cin>>t;
 while(t--){

 ll n,k;
 cin>>n>>k;
 vector<ll>arr;
 for (int i = 0; i < n; ++i)
 {
 	ll x;
 	cin>>x;
 	arr.push_back(x);
 }
 

 ll lo=1;
 ll hi=k;
 ll mid;
 while(lo<=hi){
 	mid=lo+((hi-lo)/2);
 	
 	if (is_sum(k,arr,mid)>=k)
 	{
 		hi=mid-1;
 	}
 	else{
 		lo=mid+1;
 	}
 }

 cout<<lo<<endl;


 } 
  return 0;
}