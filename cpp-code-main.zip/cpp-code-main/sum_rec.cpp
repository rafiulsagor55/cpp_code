#include<bits/stdc++.h>
using namespace std;
vector<int>dp(10000,-1);
static int cnt=0;
int solve(vector<int> &arr,int sum,vector<int>&ds,vector<vector<int>>&v) {
        
        if (sum==0)
        {
        	
        	v.push_back(ds);
        	return 0;
        }
        if (dp[sum]!=-1)
        {
        	
        	return dp[sum];
        }
        int mx=-1;
        for (int i = 0; i < arr.size(); ++i)
        {
        	if (sum>=arr[i])
        	{
        		ds.push_back(arr[i]);
        		mx=max(mx+0LL,solve(arr,sum-arr[i],ds,v)+1LL);
        		ds.pop_back();
        	}
        	
        }

          return dp[sum]=mx;
}
    int main(){
	vector<int> arr={3,2,1,4};
	vector<vector<int>>v;
	vector<int>ds;
	int x=solve(arr,5,ds,v);
	for(auto it: v){
		for(auto itt:it){
			cout<<itt<<" ";
		}
		cout<<endl;
	}
	cout<<x<<endl<<cnt<<endl;
	
	
	return 0;
}