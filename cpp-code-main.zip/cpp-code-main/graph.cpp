#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10;
bool vi[N];
vector<int>g[N];
//vector<vector<int>>cc;
//vector<int>c_cc;

bool graph(int vertex,int par){ 
    vi[vertex]=true;
    bool isloop=false;
	for(int child:g[vertex]){
		if (vi[child] && child==par) continue;
		if (vi[child]) return true;
		isloop|=graph(child,vertex);
	}
return isloop;
}
int main(){
int v,e;
cin>>v>>e;
for (int i = 0; i < e; ++i)
{
	int x1,x2;
	cin>>x1>>x2;
	g[x1].push_back(x2);
	g[x2].push_back(x1);
}
bool isloop=false;
for (int i = 1; i <= v; ++i)
{
	if(vi[i]) continue;
	isloop|=graph(i,0);
}
    cout<<isloop;

return 0;
}