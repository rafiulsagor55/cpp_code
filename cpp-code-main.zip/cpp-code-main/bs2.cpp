#include <bits/stdc++.h> 
using namespace std;
const int N=1e6+10;
vector<int>sum(N,0);
int bs(vector<int>&sum,int lo,int hi,int x){
	long long mid;
while(hi>=lo){
     mid=(lo+hi)/2;
    if (sum[mid]>=x)
    {
       hi=mid-1;

    }
    else lo=mid+1;


}
return lo ;



}




int main()
{
  int n;
  cin>>n;
  for (int i = 1; i <= n; ++i)
  {
  	int x;
  	cin>>x;
  	sum[i]=sum[i-1]+x;
  	//cout<<sum[i]<<" ";
  }
  //cout<<endl;
  int m;
  cin>>m;
  for (int i = 0; i < m; ++i)
  {
  	int b;
  	cin>>b;
  	cout<<bs(sum,1,n,b)<<endl;

  }




return 0;
}