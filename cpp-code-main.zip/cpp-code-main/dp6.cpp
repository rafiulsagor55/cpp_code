#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N= 1e5+10;
//vector<int>arr(N);
int main(){
 int t;
 cin>>t;
 while(t--){
 	int n;
 	cin>>n;
 	int mx=0;
 	int sum=0;
 	for (int i = 0; i < n; ++i)
 	{
 		int x;
 		cin>>x;
 		sum+=x;
 		mx=max(sum,mx);
 	}
 	int m;
 	cin>>m;
 	int mx1=0,sum1=0;

    for (int i = 0; i < m; ++i)
 	{
 		int x;
 		cin>>x;
 		sum1+=x;
 		mx1=max(sum1,mx1);
 	}
 	
    cout<<(mx+mx1)<<endl;



 } 
  return 0;
}