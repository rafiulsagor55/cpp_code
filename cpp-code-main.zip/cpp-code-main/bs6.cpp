#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N= 1e5+10;

int bs(int p,int n,vector<ll>&sum){
	int lo=1,hi=n;
	int mid;
	while(hi>=lo){
       
       mid=lo+((hi-lo)/2);
       if (sum[mid]>=p)
       {
       	hi=mid-1;
       }
       else{
       	lo=mid+1;
       }

	}

 return lo;
}

int main(){
 int t;
 cin>>t;
 while(t--){
 	int n,k;
 	cin>>n>>k;
 	vector<int>arr;
 	for (int i = 0; i < n; ++i)
 	{
 		ll x;
 		cin>>x;
 		arr.push_back(x);

 	}
 	sort(arr.begin(),arr.end(),greater<int>());
 	vector<ll>sum(n+1,0);
 	sum[1]=arr[0];
 	for (int i = 2; i <= n; ++i)
 	{
 		sum[i]=sum[i-1]+arr[i-1];
 	}



 	 for (int i = 0; i < k; ++i)
 	 {
 	 	ll p;
 	 	cin>>p;
 	 	if (p>sum[n])
 	 	{
 	 		cout<<"-1"<<endl;
 	 	}
 	 	else{
 	 		ll ans=bs(p,n,sum);
 	 	cout<<ans<<endl;
 	 	}
 	 	
 	 }

 } 
  return 0;
}