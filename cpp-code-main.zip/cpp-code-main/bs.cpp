#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10;
vector<int>arr(N);
vector<long long>arr1(N);

int main()
{

	long long n,m;
	cin>>n>>m;
	for (int i = 1; i <= n; ++i)
	{
		
      cin>>arr[i];
      arr1[i]=arr1[i-1]+arr[i];

      //cout<<arr1[i]<<" ";

	}
	int i=0,j=1;
	int maxi=INT_MIN;
	while(i<=n && j<=n){
		if (arr1[j]-arr1[i]<=m)
		{
			maxi=max(maxi,(j-i));
			j++;
		}
		else i++;




	}


   cout<<maxi;

	return 0;
}