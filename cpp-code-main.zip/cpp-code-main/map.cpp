#include<bits/stdc++.h>
using namespace std;
int main()
{ 
    vector<int>arr1;
    vector<int>arr2;
    vector<pair<int,int>>map,map1;
    //multimap<int,int>map;
    int n;
    cin>>n;
    for (int i = 0; i < n; ++i)
    {
       int x1;
       cin>>x1;
       arr1.push_back(x1);
    }
    for (int i = 0; i < n; ++i)
    {
       int x2;
       cin>>x2;
       arr2.push_back(x2);
    }

    for (int i = 0; i < n; ++i)
    {
       
       map.push_back({arr1[i],arr2[i]});
    }
    sort(map.begin(),map.end());

int count=0;

while(!map.empty()){

 int i=0,j=1;

while(j<=map.size()){

 if (j==map.size())
{
   map.erase(map.begin()+i); 
   break;

}

    else if (map[i].second <= map[j].first)
     {

       map.erase(map.begin()+i);
       i=j-1;

     }
   else
   {
      j++;
   }  
}
count++;
}
cout<<count;
   
return 0;
}