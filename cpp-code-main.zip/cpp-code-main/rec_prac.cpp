#include<bits/stdc++.h>
using namespace std;
vector<vector<int>>dp(100,vector<int>(100,-1));
int recurPermute(vector<int>&arr,int curr,int prev,vector<int>&ds,vector<vector<int>>&v) {
              //int ans=INT_MIN;
               if((arr.size())==curr) {
               	v.push_back(ds);
               	return 0;
               }
               if (prev!=-1)
               {
               	if (dp[curr][prev]!=-1)
               {
               	return dp[curr][prev];
               }
               }

               
               int take=0;

               if (arr[prev]<arr[curr] || prev==-1)
               { 
               	ds.push_back(arr[curr]);
               	take=1+recurPermute(arr,curr+1,curr,ds,v);
               	ds.pop_back();
               }
               int nottake=0+recurPermute(arr,curr+1,prev,ds,v);
         		if (prev!=-1)
         			 {
         			 	return dp[curr][prev]=max(take,nottake);
         			 }
         			 else return max(take,nottake);	 
         		
         	
      // return ans;
}
    int main(){
	vector<int> arr={3,1,2,5,4,7,6,9,11};
	vector<int> arr1={8,2,3,4,5,6};
	vector<vector<int>>v;
	vector<int>ds;
		
	map<vector<int>,int>mp;
	int x=recurPermute(arr1,0,-1,ds,v);
	for(auto it: v){
		for(auto itt:it){
			cout<<itt<<" ";
		}
		cout<<endl;
	}
	cout<<x<<endl<<endl;
	

	return 0;
}