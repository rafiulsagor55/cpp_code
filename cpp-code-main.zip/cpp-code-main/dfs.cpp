#include<bits/stdc++.h>
using namespace std;
#define ll long long int

void dfs(int par,ll &node,vector<int>graph[],vector<ll>&vis,map<pair<int,int>,int>&ec,ll &e_c)
{
	vis[par]=1;
	node++;
	for (int child:graph[par])
	{
		if(ec[{par,child}]==0)
		{
			e_c++;
			ec[{child,par}]=1;
			ec[{par,child}]=1;


		}
		if(vis[child]==0)
		{
            dfs(child,node,graph,vis,ec,e_c);
		}
		
	}


}
int main()
{
	int n,m;
	cin>>n>>m;
	vector<int>graph[n+1];
	vector<ll>vis(n+1,0);
	for (int i = 0; i < m; ++i)
	{
		int x,y;
		cin>>x>>y;
		graph[x].push_back(y);
		graph[y].push_back(x);
	}
	ll ans=0;

	for (int i = 1; i <= n; ++i)
	{
		if(vis[i])continue;
		map<pair<int,int>,int>ec;
		ll e_c=0;
		ll node=0;
		dfs(i,node,graph,vis,ec,e_c);
		ll ans1=(node*(node-1))/2;
		ll ans2=ans1-e_c;
		ans+=ans2;
	}
	
	cout<<ans<<endl;
	
 
  return 0;
}