#include<bits/stdc++.h>
using namespace std;
#define ll long long int
int main(){
 int t;
 cin>>t;
 while(t--){
 	int n,m,k;
 	cin>>n>>m>>k;
 	vector<int>arr1;
 	vector<int>arr2;
 	for (int i = 0; i < n; ++i)
 	{
 		int x;
 		cin>>x;
 		arr1.push_back(x);
 	}
 	sort(arr1.begin(),arr1.end());
 	for (int i = 0; i < m; ++i)
 	{
 		int x;
 		cin>>x;
 		arr2.push_back(x);
 	}
 	sort(arr2.begin(),arr2.end());
 	int ans=0;
 	for (int i = 0; i < n; ++i)
 	{
 		if (arr1[i]<=k)
 		{
 			int y=k-arr1[i];
 			vector<int> :: iterator upper;
		   upper= upper_bound(arr2.begin(),arr2.end(),y);
		   int z=upper-arr2.begin();
		   ans+=z;
 		}
 	}

     cout<<ans<<endl;



 } 
  return 0;
}