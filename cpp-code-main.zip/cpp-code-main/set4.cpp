#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N= 1e5+10;
int mx=0;
int re(set<int>&st,set<int>&s1,vector<vector<int>>&v,int idx,int n) {
      
      //mx=INT_MIN;
      
      if (idx==n )
      {
      	if (st != s1)
      	{
      		int l=s1.size();
      	 //cout<<l<<endl;
      	 mx=max(mx,l);
      	 //cout<<mx<<endl;
      	}
      	 
      	 return 0;
      }

  re(st,s1,v,idx+1,n);
  for (int i = 0; i < v[idx].size(); ++i)
  {

  	s1.insert(v[idx][i]);
  	//cout<<v[idx].size()<<endl;
  }
  re(st,s1,v,idx+1,n);
  //cout<<mx<<endl;
  return mx;

} 


int main(){
 int t;
 cin>>t;
 while(t--){
 	int n;
 	cin>>n;
 	vector<vector<int>>v;
 	set<int>st;set<int>s1;
 	for (int i = 0; i < n; ++i)
 	{    
 		vector<int>temp;
 		int k;
 		cin>>k;
 		for (int i = 0; i < k; ++i)
 		{ 
 			int x;
 			cin>>x;
 			temp.push_back(x);
 			st.insert(x);
 		}
 		v.push_back(temp);
 	}
   //int mx;
   
   mx=re(st,s1,v,0,n);
   cout<<mx<<endl;
   mx=0;



 } 
  return 0;
}