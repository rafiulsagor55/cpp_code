#include<bits/stdc++.h>
using namespace std;
#define ll long long int
int main(){
 
  int v,e;
  cin>>v>>e;
  vector<set<ll>>vs(v+10);
  for (int i = 1; i <= e; ++i)
  {
     int a,b,c;
     cin>>a>>b>>c;
     vs[a].insert(c); ,
     vs[b].insert(c);

  }
  int q;
  cin>>q;
  while(q--)
  {
    int p,q;
    cin>>p>>q;
    set<ll>s=vs[p];
    int size=vs[p].size()+vs[q].size();
    for (int it:vs[q])
    {
       s.insert(it);
    }
    cout<<(size-s.size())<<endl;
  }

  return 0;
}