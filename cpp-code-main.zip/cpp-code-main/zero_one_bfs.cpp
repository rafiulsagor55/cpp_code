#include<bits/stdc++.h>
using namespace std;
#define ll long long int
vector<int>path(100,0);
vector<int>vis(100,0);
void bfs(int par,vector<pair<int,int>>g[])
{
     deque<int>q;
     q.push_back(par);
     while(!q.empty())
     {
     	int parn=q.front();
     	vis[parn]=1;
     	q.pop_front(); 
         for(auto it:g[parn])
         {
         	if (vis[it.first]==0)
         	{
         		int child=it.first;
         	    int wt=it.second;
         	    path[child]=path[parn]+wt;
         	    if (wt==0 && vis[child]==0)q.push_front(child);
         	    else if(wt==1 && vis[child]==0)q.push_back(child);
         	    cout<<child<<" "<<path[child]<<endl;
         	}
         	
         	        	
         }
     }

}
int main()
{

    int n;
    cin>>n;
    vector<pair<int,int>>g[n+1];
    for (int i = 0; i < n; ++i)
    {
    	int x,y;
    	cin>>x>>y;
    	g[x].push_back({y,0});
    	g[y].push_back({x,1});

    }

   bfs(1,g);
   cout<<path[6]<<endl;

 
  return 0;
}