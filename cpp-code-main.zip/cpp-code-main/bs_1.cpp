#include<bits/stdc++.h>
using namespace std;
#define ll long long int
ll sum(vector<ll>&v,ll mid,ll t)
{
  ll ans=0;
  for (int i = 0; i < v.size(); ++i)
  {
    ans+=mid/v[i];
    if (ans>=t)
    {
      break;
    }

  }
  // cout<<ans<<endl;
  return ans;

}
ll bs(vector<ll>&v,ll hi,ll lo,ll t)
{
  ll mid;
  while(hi>=lo)
  {
    mid=lo+((hi-lo)/2);
    ll s=sum(v,mid,t);
    if (s>=t)
    {
      hi=mid-1;
    }
    else if (s<t)
    {
      lo=mid+1;
    }
    // else
    // {
    //   return mid;

    // }
  }
  return lo;
}
int main(){
   ll n,t;
   cin>>n>>t;
   vector<ll>v;
   for (int i = 0; i < n; ++i)
   {
     ll x;
     cin>>x;
     v.push_back(x);
   }
   sort(v.begin(),v.end());
   ll hi=1e18,lo=0;
   ll ans=bs(v,hi,lo,t);
   cout<<ans;
  
  return 0;
}
