#include<bits/stdc++.h>
using namespace std;
//vector<int>dp(10000,-1);
int recurPermute(int n,int x,int y ,int z) {
         //int ans=0;
               if(n==0) {
               	
               	return 0;
               }
               if (n<0)
               {
               	return INT_MIN;
               }
                //int a=0,b=0,c=0;       	               
         		
         			 int a=1+recurPermute(n-x,x,y,z);
         		
         			 int b=1+recurPermute(n-y,x,y,z);
         		
         			 int c=1+recurPermute(n-z,x,y,z);
         		       		
         		int ans=max(a,max(b,c));
         		
         	
      return ans;
}
    int main(){
	vector<int> arr={2,3,4,-5,-6,4,3,3};
	vector<int> arr1={1,2,3,4,5,6};
	vector<vector<int>>v;
	vector<int>ds;
		
	map<vector<int>,int>mp;
	int x=recurPermute(7,5,2,2);
	// for(auto it: v){
	// 	for(auto itt:it){
	// 		cout<<itt<<" ";
	// 	}
	// 	cout<<endl;
	// }
	cout<<x<<endl<<endl;
	// for (int i = 0; i < ds.size(); ++i)
	// {
	// 	cout<<ds[i]<<" ";
	// }

	// int y=recurPermute(arr1,4,ds,v,dp);
	// for(auto it: v){
	// 	for(auto itt:it){
	// 		cout<<itt<<" ";
	// 	}
	// 	cout<<endl;
	// }
	// cout<<y<<endl;

	return 0;
}