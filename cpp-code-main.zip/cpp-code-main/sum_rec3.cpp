#include<bits/stdc++.h>
using namespace std;
vector<vector<int>>dp(100,vector<int>(100,-1));
map<int,int>mp;
map<int,int>mp1;
vector<int>check;
vector<int>check1;
int solve(vector<int>&arr,int sum,int n,vector<int>&ds,vector<vector<int>>&v) {
        
        if (n==0)
        {
           if (sum==arr[0])
            {
            	ds.push_back(arr[0]);
            	v.push_back(ds);
            	ds.pop_back();
            	return 1;
            }
            else {
            	if (sum==0)
            	{
            		v.push_back(ds);
            		return 0;
            	}
            	else{
            	            	return INT_MIN;}
            } 
        	
        }
        
        if (dp[n][sum]!=-1)
        {
        	return dp[n][sum];
        }
                 int take=0;
                if (sum>=arr[n])
                {
                	ds.push_back(arr[n]);   
       		     take=1+solve(arr,sum-arr[n],n-1,ds,v);  
        		ds.pop_back();
                }        		
        		int nottake=solve(arr,sum,n-1,ds,v);
        		dp[n][sum]=max(take,nottake);
          	    return dp[n][sum];

            
}
    int main(){
	vector<int> arr={1,1,4,2,3,1,1,1,1,1};
	vector<vector<int>>v;
	vector<int>ds;
	
	int x=solve(arr,13,arr.size()-1,ds,v);
	for(auto it: v){
		for(auto itt:it){
			cout<<itt<<" ";
		}
		cout<<endl;
	}
	 cout<<x<<endl<<endl;
	
	return 0;
}