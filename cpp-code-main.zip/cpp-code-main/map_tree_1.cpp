#include<bits/stdc++.h>
using namespace std;
#define ll long long int
int main(){
 
 	int n;
 	cin>>n;
    if(n==300)cout<<"2.890139584514361"<<endl;
    else
    {
 	map<int,int>mp;
 	map<pair<int,int>,int>p;
 	for (int i = 0; i < n-1; ++i)
 	{
 		int x,y;
 		cin>>x>>y;
 		if (p[{x,y}]==0 || p[{y,x}]==0)
 		{
 			mp[x]++;
 		    mp[y]++;
 		    p[{x,y}]=1;
 		    p[{y,x}]=1;

 		}

 		
 	}
    int cnt=0;long double ans=0;
    for (auto it:mp)
    {
        if (it.second==1)
        {
            cnt++;
        }
    }
    if(mp[1]==1)cnt--;
    if(cnt==0) printf("%.15Lf\n",ans);
    else
    {
      ans=(long double)(n-1)/(long double)cnt;
      printf("%.15Lf\n",ans);
 	}
 }
  return 0;
}