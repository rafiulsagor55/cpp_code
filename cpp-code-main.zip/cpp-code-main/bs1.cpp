#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N= 1e5+10;
vector<int>arr(N);

int bs(int n,int k){

	ll lo =1;
	ll hi= 2*k;
	ll mid;
	while(lo<=hi){
       mid = lo+((hi-lo)/2);
       ll x=mid/n;
       //if((mid-x)==k) return mid;
      if((mid-x)>=k){
        hi=mid-1;
       }
       else lo=mid+1;
	}

return lo;

}
int main(){
 int t;
 cin>>t;
 for (int i = 0; i < t; ++i)
 {
 	ll n,k;
 	cin>>n>>k;

    if (n>k)
    {
    	cout<<k<<endl;
    }
    else if (n==k)
    {
    	cout<<(n+1)<<endl;
    }
    else if (n==2)
    {
    	cout<<((2*k)-1)<<endl;
    }
   
    else
    {

        ll bs1=bs(n,k);
        cout<<bs1<<endl;

    }

 }

  return 0;
}
