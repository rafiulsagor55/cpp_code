#include<bits/stdc++.h>
using namespace std;
vector<int>dp(100,-1);
map<int,int>mp;
map<int,int>mp1;
vector<int>check;
vector<int>check1;

int solve(int n,int x,int y,int z,vector<int>&ds) {

    if (n==0)
    {
    	return 0;
    }
    if (n<0)
    {
    	return -1111;
    }
    if (dp[n]!=-1)
    {
    	return dp[n];
    }
    int a=solve(n-x,x,y,z,ds)+1;
    int b=solve(n-y,x,y,z,ds)+1;
    int c=solve(n-z,x,y,z,ds)+1;
    // return 
    return dp[n]=max(a,max(b,c));


}
    int main(){
	vector<int> arr={4,3,2,1,1};
	vector<vector<int>>v;
	vector<int>ds;
	vector<int>freq(arr.size(),-1);
int x=solve(12,3,4,2,ds);
cout<<x<<endl;
	
	
	return 0;
}