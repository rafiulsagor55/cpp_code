#include<bits/stdc++.h>
using namespace std;
#define ll long long int
int main(){
 int t;
 cin>>t;
 while(t--)
 {
 	int n,m;
 	cin>>n>>m;
 	map<int,int>mp;
 	map<pair<int,int>,int>p;
 	for (int i = 0; i < m; ++i)
 	{
 		int x,y;
 		cin>>x>>y;
 		if (p[{x,y}]==0 || p[{y,x}]==0)
 		{
 			mp[x]++;
 		    mp[y]++;
 		    p[{x,y}]=1;
 		    p[{y,x}]=1;

 		}
 		
 	}
 	map<int,int>mp1;
 	for (int i = 1; i <= n; ++i)
 	{
 		if (mp[i]>1)
 		{	
 			mp1[mp[i]]++;
 		}
 	}
 	int x1=0,y1=0;
 	for (auto it:mp1)
 	{
 		if (it.second>1)
 		{
 			y1=it.first;
 		}
 		else if(it.second==1)
 		{
 			x1=it.first;
 		}
 	}
 	if(x1==0)x1=y1;
 	else if(y1==0)y1=x1;
 	cout<<x1<<" "<<(y1-1)<<endl;

 } 
  return 0;
}