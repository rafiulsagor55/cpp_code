#include<bits/stdc++.h>
using namespace std;
#define ll long long int
int dfs(int par,ll &node,vector<int>graph[],vector<ll>&vis,map<int,int>&ec,ll &isloop)
{
	vis[par]=1;
	node++;
	if (ec[par]==2)
	{
		isloop=isloop&&1;
	}
	else isloop=isloop&&0;
	for (int child:graph[par])
	{
		
		if(vis[child]==0)
		{
            dfs(child,node,graph,vis,ec,isloop);
		}
		
	}

   return isloop; 

}
int main()
{
	int n,m;
	cin>>n>>m;
	vector<int>graph[n+1];
	vector<ll>vis(n+1,0);
	map<int,int>ec;
	for (int i = 0; i < m; ++i)
	{
		int x,y;
		cin>>x>>y;
		graph[x].push_back(y);
		graph[y].push_back(x);
		ec[x]++;
		ec[y]++;
	}
	ll ans=0;
    
	for (int i = 1; i <= n; ++i)
	{
		ll node=0;
		ll isloop=1;
		if(vis[i])continue;
		int flag=dfs(i,node,graph,vis,ec,isloop);
		if (flag==1 && node>=3)
		{
			ans++;
		}
		
	}
	
	cout<<ans<<endl;
	
 
  return 0;
}