#include<bits/stdc++.h>
using namespace std;
#define ll long long
int main()
{
	int t;
	cin>>t;
	while(t--)
	{
	int n;
	cin>>n;
	ll a,b,c;
	cin>>a>>b>>c;

	map<pair<ll,ll>,ll>ab1;
	map<pair<ll,ll>,map<ll,ll>>ab2;
    ab1[{a,b}]++;
    ab2[{a,b}][c]++;

    map<pair<ll,ll>,ll>bc1;
	map<pair<ll,ll>,map<ll,ll>>bc2;
    bc1[{b,c}]++;
    bc2[{b,c}][a]++;

    map<pair<ll,ll>,ll>ac1;
	map<pair<ll,ll>,map<ll,ll>>ac2;
    ac1[{a,c}]++;
    ac2[{a,c}][b]++;
    ll ans=0;
	for (int i = 0; i < n-3; ++i)
	{
		a=b;
		b=c;
		cin>>c;
		ll y1=ab1[{a,b}];
		ll y2=ab2[{a,b}][c];
        ans+=y1-y2;

        ll z1=bc1[{b,c}];
		
		ll z2=bc2[{b,c}][a];
        ans+=z1-z2;

        ll k1=ac1[{a,c}];
		
		ll k2=ac2[{a,c}][b];
        ans+=k1-k2;
        
        
        ab1[{a,b}]++;
        
        ab2[{a,b}][c]++;
        
        
        bc1[{b,c}]++;
	    
	    bc2[{b,c}][a]++;
        
       
        ac1[{a,c}]++;
	   
	    ac2[{a,c}][b]++;

	}

	cout<<ans<<endl;
	}
  
  return 0;
}
