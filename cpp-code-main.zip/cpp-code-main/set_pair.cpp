#include<bits/stdc++.h>
using namespace std;

void calculate_possible_positions(int n, int m, int x, vector<pair<int, char>>& throws) 
{
    set<int> possible_positions;
    possible_positions.insert(x);

    for (auto& throw_info : throws) 
    {
        int r = throw_info.first;
        char c = throw_info.second;
        set<int> new_possible_positions;

        for (int position : possible_positions) {
            if (c == '0') {  // Clockwise
                int new_position = (position + r) % n;
                new_possible_positions.insert(new_position);
            } else if (c == '1') {  // Counterclockwise
                int new_position = (position - r + n) % n;
                new_possible_positions.insert(new_position);
            } else {  // Both directions
                int new_position_clockwise = (position + r) % n;
                new_possible_positions.insert(new_position_clockwise);

                int new_position_counterclockwise = (position - r + n) % n;
                new_possible_positions.insert(new_position_counterclockwise);
            }
        }

        possible_positions = new_possible_positions;
    }

    cout << possible_positions.size() << endl;
    for (int position : possible_positions) {
        cout << position + 1 << " ";
    }
    cout << endl;
}

int main() {
    int t;
    cin >> t;

    for (int i = 0; i < t; ++i) {
        int n, m, x;
        cin >> n >> m >> x;
        
        vector<pair<int, char>> throws;
        for (int j = 0; j < m; ++j) {
            int r;
            char c;
            cin >> r >> c;
            throws.push_back({r, c});
        }

        calculate_possible_positions(n, m, x - 1, throws);
    }

    return 0;
}
