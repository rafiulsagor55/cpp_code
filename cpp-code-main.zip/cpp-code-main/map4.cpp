#include<bits/stdc++.h>
using namespace std;
#define ll long long int
void show(map<int, set<int> >& mapOfSet)
{
    // Using iterator to access
    // key, value pairs present
    // inside the mapOfSet
    for (auto it = mapOfSet.begin();it != mapOfSet.end();it++) 
    {
 
        // Key is integer
        cout << it->first << " => ";
 
        // Value is a set of string
        set<int> st = it->second;
 
        // Strings will be printed
        // in sorted order as set
        // maintains the order
        for (auto it = st.begin();
             it != st.end(); it++) {
            cout << (*it) << ' ';
        }
        cout << '\n';
    }
}
int main(){
	map<int,priority_queue<int>>p_map;
	priority_queue<int>p;
	p.push(1);
	p.push(2);
	p.push(1);
	p_map[1]=p;

	 cout<<p_map[1].top();

	// map<int,set<int>>v_map;
	// set<int>v;
	// v.insert(3);
	// v.insert(6);
	// v.insert(9);
	// // v_map.insert({1,v});
	// v_map[1]=v;
	// show(v_map);

  
  return 0;
}
